KUASHA PORTFOLIO — PUBLISHING GUIDE

Your website files are ready. The site is NOT public yet.

EASIEST NEXT STEPS (GitHub Pages):
1. Sign in or create an account at https://github.com/
2. Create a new public repository named exactly: YOUR-USERNAME.github.io
   Replace YOUR-USERNAME with your GitHub username.
3. Upload index.html from this folder to the repository root.
4. In the repository, open Settings -> Pages. If needed, choose Deploy from a branch,
   select the main branch and /(root), then Save.
5. Wait for GitHub Pages to publish the site. The address will be:
   https://YOUR-USERNAME.github.io/
6. Open the address in a private/incognito browser window to confirm it works.
7. Open https://search.google.com/search-console/ and add your public website address.
   Complete the verification steps shown by Google.
8. Use URL Inspection for the home page and select Request Indexing.
   Google indexing can take days or longer and is not guaranteed.

IMPORTANT:
- Do not share your GitHub password with anyone.
- After the site is published, edit sitemap.xml and replace
  https://YOUR-SITE-ADDRESS-HERE/ with the actual public website address, then upload it.
- The files in this package do not themselves publish the website.
